ace.define("ace/snippets/lean",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "lean";

});
