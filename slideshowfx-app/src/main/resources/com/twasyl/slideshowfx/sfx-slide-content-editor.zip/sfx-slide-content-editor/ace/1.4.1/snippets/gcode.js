ace.define("ace/snippets/gcode",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="gcode"});
                (function() {
                    ace.require(["ace/snippets/gcode"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            